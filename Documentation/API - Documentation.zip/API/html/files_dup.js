var files_dup =
[
    [ "Plugins", "dir_0b4eaef40a1fe20bedafe9e8e719ce66.html", "dir_0b4eaef40a1fe20bedafe9e8e719ce66" ]
];